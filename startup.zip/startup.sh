#!/bin/bash
cd /home/site/wwwroot

# Ensure Laravel folders have correct permissions
mkdir -p storage bootstrap/cache
chmod -R 775 storage bootstrap/cache
chmod -R 755 public

# Clear and cache Laravel configs
php artisan config:clear
php artisan route:cache
php artisan view:cache

# Start PHP built-in server pointing to public
php -S 0.0.0.0:8080 -t public